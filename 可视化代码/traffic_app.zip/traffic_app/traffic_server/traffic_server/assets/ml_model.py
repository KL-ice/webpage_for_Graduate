import torch
import json
import time
from .dcnn_model import *
from .seq2seq_model import *
from .gat_model import GAT, SpGAT
from .config import *
from .dLoader import *
from .method import *

'''
model = SpGAT(nfeat=INPUT_WIDTH, 
                nhid=FEATURE_SIZE,
                nclass=OUTPUT_WIDTH, 
                dropout=DROP_OUT, 
                nheads=ATTENTION_LEVEL, 
                alpha=LEAKY_ALPHA,
                cuda=True)

model.load_state_dict(torch.load(ROOT_PATH + '/model.pkl'))
'''
device = torch.device('cuda:0')
fix = AttnSeq2Seq(ERROR_LEVEL * OUTPUT_WIDTH, 1, FEATURE_SIZE, OUTPUT_WIDTH, layer = 1, dropout = 0.2, device = device)
fix.load_state_dict(torch.load(ROOT_PATH + '/SEQ2SEQ_beijing_I{}_D0_O{}.pkl'.format(INPUT_WIDTH, OUTPUT_WIDTH)))
fix.cuda()
fix.eval()
'''
dcnn = LinearCnn(INPUT_WIDTH, OUTPUT_WIDTH, 1)
'''
dcnn = DCNN(output_size=OUTPUT_WIDTH, 
                in_channel=INPUT_WIDTH,
                step=24, 
                out_channel=CNN_CHANNEL,
                level=CNN_LEVEL)
dcnn.load_state_dict(torch.load(ROOT_PATH + '/DCNN_beijing_I{}_D0_O{}.pkl'.format(INPUT_WIDTH, OUTPUT_WIDTH)))
dcnn.cuda()
dcnn.eval()

model = LinearDiffDim(INPUT_WIDTH, OUTPUT_WIDTH, 1)
model.load_state_dict(torch.load(ROOT_PATH + '/ARIMA_beijing_I{}_D0_O{}.pkl'.format(INPUT_WIDTH, OUTPUT_WIDTH)))
model.cuda()
model.eval()

models = [model, dcnn]


# Load data
dataSet = networkRoadDataset(ROAD_SET)
roads = []

with open(DATA_PATH + '/data-' + ROAD_SET + '/road_net.json') as f:
    road_net = json.load(f)
#roads = list(road_net.keys())

pi_res = json.load(open(ROOT_PATH + '/pais.json', 'r'))
sub_roads_arima = []
sub_roads_hcnn = []
for k in pi_res:
    val = pi_res[k]
    if val[1] > val[4]:
        sub_roads_arima.append(k)
    else:
        sub_roads_hcnn.append(k)

sub_roads_arima.sort(key = lambda x: pi_res[x][1])
step_arima = 0
sub_roads_hcnn.sort(key = lambda x: pi_res[x][1])
step_hcnn = 0
for i in range(len(sub_roads_arima)):
    if pi_res[sub_roads_arima[i]][1] > 0.6:
        step_arima = i
        break
for i in range(len(sub_roads_hcnn)):
    if pi_res[sub_roads_hcnn[i]][1] > 0.6:
        step_hcnn = i
        break
step_arr = [step_arima, step_hcnn]

roads = sub_roads_arima + sub_roads_hcnn
collect_err = [[torch.zeros([step_arr[j], OUTPUT_WIDTH]).to(device) for i in range(ERROR_LEVEL)] for j in range(len(step_arr))]

len_roads = len(roads)
batch_len = dataSet.loadDataSet(roads, NEIGHBOUR_LEVEL, in_window = INPUT_WIDTH, delay_window = DELAY_WIDTH, out_window = OUTPUT_WIDTH)
adj = dataSet.getAdj(roads)
loader = [dataSet.getBatch(sub_roads_arima), dataSet.getImageBatch(sub_roads_hcnn, NUMPY(adj), level = MAX_LEVEL)]
last_mae = [0 for i in range(len_roads)]
last_mape = [0 for i in range(len_roads)]
last_rmse = [0 for i in range(len_roads)]
last_loss = 0

def getBatchLen():
    return batch_len

def resetLoader():
    global loader
    loader = [dataSet.getBatch(sub_roads_arima), dataSet.getImageBatch(sub_roads_hcnn, NUMPY(adj), level = MAX_LEVEL)]
    
def getNext():
    start = time.time()
    global last_mae
    global last_mape
    global last_rmse
    global last_loss
    _y, _y_max, _y_mean, _out = [], [], [], []
    cost_seq2seq, cost_arima, cost_hcnn = 0, 0, 0
    for i in range(len(loader)):
        tp_loader = loader[i]
        (x, y, y_max, y_mean, step) = next(tp_loader)
        if i == 0:
            cost_arima = time.time()
            (x, y, y_max, y_mean) = x.float().cuda(), y.float().cuda(), y_max.float().cuda(), y_mean.float().cuda()
            output = models[i](x)
            cost_arima = time.time() - cost_arima
        else:
            cost_hcnn = time.time()
            (y, y_max, y_mean) = y.float().cuda(), y_max.float().cuda(), y_mean.float().cuda()
            N = len(x)
            output = torch.stack([ models[i]((x[k]).float().to(device)) for k in range(N) ]).squeeze()
            cost_hcnn = time.time() - cost_hcnn
            #print(output)
        cost_s2s = time.time()
        err_input = torch.stack(collect_err[i]).view(step_arr[i], -1)
        real_error = (y[:step_arr[i]] - output[:step_arr[i]])
        err_output = fix(err_input, real_error, 0)
        collect_err[i].pop(0)
        collect_err[i].append((output[:step_arr[i]] - y[:step_arr[i]]).detach())
        output[:step_arr[i]] += err_output
        cost_s2s = time.time() - cost_s2s
        cost_seq2seq += cost_s2s
        _y.append(y)
        _y_max.append(y_max)
        _y_mean.append(y_mean)
        _out.append(output)
    y = torch.cat(_y)
    y_max = torch.cat(_y_max)
    y_mean = torch.cat(_y_mean)
    output = torch.cat(_out)
    
    #output = model(x, adj)
    diff = torch.abs(output - y)
    loss = torch.mean(diff.mul(y_max)).item()
    mae = torch.mean(diff.mul(y_max), dim = 1).data.cpu().numpy().tolist()
    mape = torch.mean(100 * diff / (y + y_mean + 1e-9), dim = 1).data.cpu().numpy().tolist()
    rmse = torch.mean((diff.mul(y_max) ** 2) ** 0.5, dim = 1).data.cpu().numpy().tolist()
    acc = (1 - torch.mean(diff)).item()
    res = {}
    data = {}
    for i in range(len_roads):
        data[roads[i]] = ((output[i] + y_mean[i]).mul(y_max[i])).data.cpu().numpy().tolist()
        res[roads[i]] = [last_mae[i], last_mape[i], last_rmse[i]]
    resp = {
        'data': data,
        'res': res,
        'loss': last_loss,
        'cost': [cost_arima+cost_seq2seq+cost_hcnn, cost_arima, cost_seq2seq, cost_hcnn],
        'step': step,
    }
    #print([cost_arima, cost_seq2seq, cost_hcnn])
    #print(last_loss)
    last_mae = mae
    last_mape = mape
    last_rmse = rmse
    last_loss = loss
    return resp

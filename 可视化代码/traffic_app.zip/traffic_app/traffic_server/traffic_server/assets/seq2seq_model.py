import torch
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
import random

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

class Seq2Seq(nn.Module):
    def __init__(self, input_dim, hid_dim, n_layers, out_step, dropout = None, device = device):
        super(Seq2Seq, self).__init__()
        self.level = 1
        self.encoder = nn.GRU(input_dim, hid_dim, n_layers)
        self.decoder = nn.GRU(input_dim, hid_dim, n_layers)
        self.input_dim = input_dim
        self.hid_dim = hid_dim
        self.device = device
        self.layers = n_layers
        self.out_step = out_step // input_dim

    def forward(self, x):
        _x = torch.stack(x.chunk(self.input_dim, dim = 1), dim = 2).permute(1, 0, 2)
        #_x = x
        #x.shape = [N, batch, input_dim]
        batch_size = _x.shape[1]
        feature, hidden = self.encoder(_x)
        #output.shape = [N, batch, hid_dim]

        outputs = []
        decorder_input = feature[-1].unsqueeze(0)[:, :, :self.input_dim]
        for i in range(self.out_step):
            decoder_output, hidden  = self.decoder(decorder_input, hidden)
            output = decoder_output[:, :, :self.input_dim]
            #output.shape = [1, batch, input_dim]
            outputs.append(output)
            decorder_input = output
            #decorder_input = _y[i].unsqueeze(0)
            #input.shape = [1, batch, input_dim]
        return torch.cat(outputs, dim = 2).squeeze()

class Seq2SeqWithNB(nn.Module):
    def __init__(self, input_dim, hid_dim, n_layers, out_step, cnn_dim = 4, dropout = None, device = device):
        super(Seq2SeqWithNB, self).__init__()
        self.cnn_dim = cnn_dim
        self.input_dim = input_dim + 1
        self.conv1d = nn.Conv1d(input_dim, self.cnn_dim, 4, 1, padding = 2)
        self.pool1d = nn.MaxPool1d(2, 2)
        self.encoder = nn.GRU(self.input_dim, hid_dim, n_layers)
        self.decoder = nn.GRU(input_dim, hid_dim, n_layers)
        self.fc = nn.Sequential(
            nn.Linear(hid_dim, input_dim),
            nn.Sigmoid(),
        )
        self.dense = nn.Linear(190, 1)
        self.hid_dim = hid_dim
        self.device = device
        self.layers = n_layers
        self.out_step = out_step

    def forward(self, x):
        N = x.shape[0]
        L = x.shape[2]
        _x = x[:, :, 0]
        _x_neighbour = x[:, :, 1:]
        #print(_x_neighbour.shape)
        _x_neighbour = _x_neighbour.reshape(N, 1, -1)
        _x_neighbour_conv = self.conv1d(_x_neighbour)
        _x_neighbour_pool = self.pool1d(_x_neighbour_conv)
        #print(_x_neighbour_pool.view(N, x.shape[1], -1).shape)
        _x_neighbour_fc = self.dense(_x_neighbour_pool.view(N, x.shape[1], -1)).squeeze()
        #print(_x_neighbour_fc.shape)

        _x = torch.stack([x[:, :, 0], _x_neighbour_fc], dim = 2).permute(1, 0, 2)
        #print(_x.shape)
        #x.shape = [N, batch, input_dim]
        batch_size = _x.shape[1]
        feature, hidden = self.encoder(_x)
        #output.shape = [N, batch, hid_dim]

        outputs = []
        decorder_input = self.fc(feature[-1].unsqueeze(0))
        for i in range(self.out_step):
            decoder_output, hidden  = self.decoder(decorder_input, hidden)
            output = self.fc(decoder_output)
            #output.shape = [1, batch, input_dim]
            outputs.append(output)
            decorder_input = output
            #decorder_input = _y[i].unsqueeze(0)
            #input.shape = [1, batch, input_dim]
        return torch.stack(outputs, dim = 0)

class Feedback(nn.Module):
    def __init__(self, window_width):
        super(Feedback, self).__init__()
        self.width = window_width
        if self.width:
            self.linear = LinearDim(self.width, 1, 0, False)

    def forward(self, y, shift_errors):
        if self.width:
            y += self.linear(torch.stack(shift_errors[-self.width:])).squeeze(0)
        return y
        
class EncoderRNN(nn.Module):
    def __init__(self, input_size, hidden_size, layer = 1, device = device):
        super(EncoderRNN, self).__init__()
        self.hidden_size = hidden_size
        self.layer = layer
        self.embedding = nn.Linear(input_size, hidden_size)
        self.gru = nn.GRU(hidden_size, hidden_size, layer)
        self.device = device
        

    def forward(self, input):
        # input [step, batch_len, input_dim]
        steps = input.shape[0]
        batch_len = input.shape[1]
        embedded = self.embedding(input).view(-1, batch_len, self.hidden_size)
        outputs = []
        hiddens = []
        hidden = torch.zeros(self.layer, batch_len, self.hidden_size, device = self.device)
        for i in range(steps):
            output, hidden = self.gru(embedded[i].unsqueeze(0), hidden)
            outputs.append(output)
            hiddens.append(hidden)
        return outputs, hiddens

class AttnDecoderRNN(nn.Module):
    def __init__(self, hidden_size, output_size, layer=1, dropout_p=0.1, max_length=10, device = device):
        super(AttnDecoderRNN, self).__init__()
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.dropout_p = dropout_p
        self.max_length = max_length
        self.layer = layer

        self.embedding = nn.Linear(self.output_size, self.hidden_size)
        self.attn = nn.Linear(self.hidden_size * 2, self.max_length)
        self.attn_combine = nn.Linear(self.hidden_size * 2, self.hidden_size)
        self.dropout = nn.Dropout(self.dropout_p)
        self.gru = nn.GRU(self.hidden_size, self.hidden_size, layer)
        self.out = nn.Linear(self.hidden_size, self.output_size)
        self.device = device

    def forward(self, input, hidden, encoder_outputs):
        # input [1, batch_len, input_dim]
        batch_len = input.shape[1]
        embedded = self.embedding(input).view(-1, batch_len, self.hidden_size)
        embedded = self.dropout(embedded)

        attn_weights = F.softmax(
            self.attn(torch.cat((embedded[0], hidden[0]), 1)), dim=1)
        attn_applied = torch.bmm(attn_weights.unsqueeze(1),
                                 encoder_outputs).squeeze()

        output = torch.cat((embedded[0], attn_applied), 1)
        output = self.attn_combine(output).unsqueeze(0)

        output = F.leaky_relu(output, 0.2)
        output, hidden = self.gru(output, hidden)

        output = self.out(output[0])
        return output, hidden, attn_weights
     
class AttnSeq2Seq(nn.Module):
    def __init__(self, input_size, step_size, hidden_size, output_size, layer=1, dropout=0.1, device = device):
        super(AttnSeq2Seq, self).__init__()
        self.step_size = step_size
        self.input_steps = input_size // step_size
        self.output_steps = output_size // step_size
        self.encoder = EncoderRNN(step_size, hidden_size, layer, device = device).to(device)
        self.decoder = AttnDecoderRNN(hidden_size, step_size, layer, dropout_p = dropout, max_length = self.input_steps, device = device).to(device)
        self.device = device
    
    def forward(self, x, y, teacher_forcing_ratio = 0.1):
        use_teacher_forcing = True if random.random() < teacher_forcing_ratio else False
        input = x.view(self.input_steps, -1, self.step_size)
        real = y.view(self.output_steps, -1, self.step_size)
        #[input_steps, batch, step_size]
        output, hidden = self.encoder(input)
        # [1, batch, hidden]*step
        # [layer, batch, hidden]*step
        encoder_output = torch.cat(output, dim = 0).permute(1, 0, 2)
        # [batch, step, hidden]
        out = torch.zeros_like(real[0].unsqueeze(0), device = self.device)
        # [1, batch, hidden]
        outs = []
        if use_teacher_forcing:
            for i in range(self.output_steps):
                out, hid, weight = self.decoder(out, hidden[-1], encoder_output)
                outs.append(out)
                hidden.append(hid)
                out = real[i].unsqueeze(0)
        else:
            for i in range(self.output_steps):
                out, hid, weight = self.decoder(out, hidden[-1], encoder_output)
                outs.append(out)
                hidden.append(hid)
                out = out.detach().unsqueeze(0)
        return torch.cat(outs, dim = 1)



if __name__ == "__main__":
    with torch.autograd.set_detect_anomaly(True):
        model = Seq2Seq(1, 128, 2, 8, device = torch.device('cpu'))
        x = torch.randn(100, 96)
        y = torch.randn(100, 8)
        out = model(x)
        loss = F.mse_loss(out, y)
        loss.backward()
        x = torch.randn(87, 16).float().cuda()
        y = torch.randn(87, 8).float().cuda()
        model = AttnSeq2Seq(16, 2, 64, 8)
        out = model(x, y, 1)
        #print(out)
        '''
        x = torch.randn(8, 87, 2).float().cuda()
        # [step, batch, input]
        encoder = EncoderRNN(2, 32).cuda()
        out, hid = encoder(x)
        print(out[-1].shape)
        # [1, batch, hidden]*step
        print(hid[-1].shape)
        # [layer, batch, hidden]*step
        attn_decoder = AttnDecoderRNN(32, 2, dropout_p=0.1, max_length=8).cuda()
        e_out = torch.cat(out, dim = 0).permute(1, 0, 2)
        # [batch, step, hidden]
        out = torch.zeros(1, 87, 2).cuda()
        # [1, batch, out]
        out, hide, weight = attn_decoder(out, hid[-1], e_out)
        print(out.shape)
        # [1, batch, out]
        print(hide.shape)
        # [1, batch, hid]
        print(weight)
        # [batch, step]
        '''
        

import torch
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
from collections import OrderedDict


class LinearCnn(nn.Module):
    '''
    linear regression at given dim
    '''
    def __init__(self, input_size, output_size, dim, step = 24, clip = 3, bias = True):
        super(LinearCnn, self).__init__()
        self.dim = dim
        self.clip = clip
        self.in_channel = input_size // step
        self.linear = nn.Sequential(OrderedDict([
            ('linear', nn.Conv2d(self.in_channel, output_size, (step, 1))),
        ]))
        '''
        self.linear = nn.Conv2d(self.in_channel, output_size, (step, 1))
        '''

    def forward(self, x):
        N = x.shape[0]
        L = x.shape[2]
        if L > self.clip:
            L = self.clip
        k = x[:, :, :L].view(N, self.in_channel, -1, L)
        y = self.linear(k)
        y = torch.mean(y.view(y.size(0), y.size(1), -1), dim=2)
        return y

class LinearDim(nn.Module):
    '''
    linear regression at given dim
    '''
    def __init__(self, input_size, output_size, dim, bias = True):
        super(LinearDim, self).__init__()
        self.in_size = input_size
        self.out_size = output_size
        self.dim = dim
        self.linear = nn.Linear(self.in_size, self.out_size, bias = bias)

    def forward(self, x):
        max_dim = len(list(x.shape)) - 1
        x = torch.transpose(x, self.dim, max_dim)
        x = self.linear(x)
        x = torch.transpose(x, self.dim, max_dim)
        return x

class LinearHack(nn.Module):
    '''
    linear regression at given dim
    '''
    def __init__(self, input_size, step_size, output_size, dim, bias = True):
        super(LinearHack, self).__init__()
        self.in_size = input_size
        self.step_size = step_size
        self.out_size = output_size
        self.level = 1
        self.dim = dim
        self.device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
        self.linear = nn.Linear(self.in_size - self.level, self.step_size, bias = bias)

    def forward(self, x):
        zeros = torch.zeros(x.shape).to(self.device)
        arr = [x]
        for i in range(self.level):
            tp = arr[-1]
            arr.append((tp - torch.cat([zeros[:, :1], tp[:, :-1]], dim = 1))[:, :-1])
        max_dim = len(list(x.shape)) - 1
        tp = arr[-1]
        tp = torch.transpose(tp, self.dim, max_dim)
        #out = torch.mm(tp, self.W)
        step = self.out_size // self.step_size
        final_out = []
        for i in range(step):
            out = self.linear(tp)
            tp = torch.cat([tp[:,self.step_size:], out], dim = 1)
            final_out.append(out)
        out = torch.cat(final_out, dim = 1)
        out = torch.transpose(out, self.dim, max_dim)
        for i in range(self.level):
            out[:, 0] += arr[self.level - 1 - i][:, -1]
            for i in range(1, self.out_size):
                out[:, i] += out[:, i - 1]
        return out

class LinearDiffDim(nn.Module):
    '''
    linear regression at given dim
    '''
    def __init__(self, input_size, output_size, dim, bias = True):
        super(LinearDiffDim, self).__init__()
        self.in_size = input_size
        self.out_size = output_size
        self.dim = dim
        self.level = 1
        self.device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
        self.linear = nn.Linear(self.in_size - self.level, self.out_size, bias = bias)
        '''
        self.linear = nn.Sequential(OrderedDict([
            ('linear', nn.Linear(self.in_size - self.level, self.out_size, bias = bias)), 
            ('leaky', nn.LeakyReLU())
        ]))
        '''

    def forward(self, x):
        zeros = torch.zeros(x.shape).to(self.device)
        arr = [x]
        for i in range(self.level):
            tp = arr[-1]
            arr.append((tp - torch.cat([zeros[:, :1], tp[:, :-1]], dim = 1))[:, :-1])
        max_dim = len(list(x.shape)) - 1
        tp = arr[-1]
        tp = torch.transpose(tp, self.dim, max_dim)
        #out = torch.mm(tp, self.W)
        out = self.linear(tp)
        out = torch.transpose(out, self.dim, max_dim)
        for i in range(self.level):
            out[:, 0] += arr[self.level - 1 - i][:, -1]
            for i in range(1, self.out_size):
                out[:, i] += out[:, i - 1]
        return out
    
    def getW(self):
        return self.state_dict()['linear.weight'].data

class LinearPickDim(nn.Module):
    '''
    linear regression at given dim
    '''
    def __init__(self, input_size, output_size, dim, bias = True):
        super(LinearPickDim, self).__init__()
        self.in_size = input_size
        self.out_size = output_size
        self.dim = dim
        self.linear = nn.Linear(2*self.out_size, self.out_size, bias = bias)

    def forward(self, x):
        x = torch.cat([x[:, :self.out_size], x[:, -self.out_size:]], 1)
        max_dim = len(list(x.shape)) - 1
        x = torch.transpose(x, self.dim, max_dim)
        x = self.linear(x)
        x = torch.transpose(x, self.dim, max_dim)
        return x

class InputAvgLayer(nn.Module):
    def __init__(self, input_size, output_size):
        super(InputAvgLayer, self).__init__()
        self.in_size = input_size
        self.out_size = output_size

    def forward(self, x):
        N = x.shape[0]
        #_out = torch.mean(x, dim = 1).view(N, 1).expand(N, self.out_size)
        _out = x[:, :self.out_size]
        return _out

class LastInputLayer(nn.Module):
    def __init__(self, input_size):
        super(InputAvgLayer, self).__init__()
        self.in_size = input_size

    def forward(self, x):
        _out = torch.mean(x, dim = 1)
        return x

class Feedback(nn.Module):
    def __init__(self, window_width):
        super(Feedback, self).__init__()
        self.width = window_width
        if self.width:
            self.linear = LinearDim(self.width, 1, 0, False)

    def forward(self, y, shift_errors):
        if self.width:
            y += self.linear(torch.stack(shift_errors[-self.width:])).squeeze(0)
        return y

class DCNN(nn.Module):
    '''
    Multi level CNN with Resnet (each layer with same shape)
    '''
    def __init__(self, output_size, in_channel, out_channel, step = 4, kernel_size = 3, stride = 1, level = 3, shortcut = 3):
        super(DCNN, self).__init__()

        self.level = level
        self.padding =(kernel_size - 1) // 2
        self.in_channel = in_channel // step
        self.shortcut = shortcut

        self.ConvLayers = []
        for i in range(level):
            tp_conv = []
            if i > 0:
                tp_conv.append(('conv', nn.Conv2d(out_channel, out_channel, kernel_size, stride, padding = self.padding)))
            else:
                tp_conv.append(('conv', nn.Conv2d(self.in_channel, out_channel, kernel_size, stride, padding = self.padding)))
            tp_conv.append(('relu', nn.ELU()))
            conv = nn.Sequential(OrderedDict(tp_conv))
            self.ConvLayers.append(conv)
            self.add_module('conv_{}'.format(i), conv)

        #self.PoolLayers = nn.AvgPool2d(2)
        self.cnn_base = LinearCnn(in_channel, output_size, 1, step = step)
        self.W = nn.Parameter(torch.zeros(size=(out_channel, output_size)))
        nn.init.xavier_uniform_(self.W.data, gain=1.414)

    def forward(self, x):
        _shape = x.shape
        N = x.shape[0]
        L = x.shape[2]
        _x = [x.view(N, self.in_channel, -1, L)]
        shortcut_point = self.shortcut - 1
        for i in range(self.level):
            _x_input = _x[i]
            #print(_x_input.shape)
            if (self.shortcut) and (i % self.shortcut == shortcut_point):
                _x_input = _x_input + _x[i - shortcut_point]
            #print(i)
            _x.append(self.ConvLayers[i](_x_input))
        _x_fc = _x[-1]
        _x_pool = torch.mean(_x_fc.view(_x_fc.size(0), _x_fc.size(1), -1), dim=2)
        #print(_x[-1])
        #print(_x_pool.shape)
        out = torch.mm(_x_pool, self.W) + self.cnn_base(x)
        return out

if __name__ == "__main__":
    model = DCNN(1, 1, 18, level = 1)
    x = torch.randn(50, 96, 3).unsqueeze(1)
    y = model(x)
    print(y.shape)
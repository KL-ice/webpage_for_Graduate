import numpy as np
import torch
from graphviz import Digraph

def LCS(s1, s2):
    size1 = len(s1) + 1
    size2 = len(s2) + 1
    chess = [[["", 0] for j in list(range(size2))] for i in list(range(size1))]
    for i in list(range(1, size1)):
        chess[i][0][0] = s1[i - 1]
    for j in list(range(1, size2)):
        chess[0][j][0] = s2[j - 1]
    for i in list(range(1, size1)):
        for j in list(range(1, size2)):
            if s1[i - 1] == s2[j - 1]:
                chess[i][j] = ['↖', chess[i - 1][j - 1][1] + 1]
            elif chess[i][j - 1][1] > chess[i - 1][j][1]:
                chess[i][j] = ['←', chess[i][j - 1][1]]
            else:
                chess[i][j] = ['↑', chess[i - 1][j][1]]
    i = size1 - 1
    j = size2 - 1
    s3 = []
    while i > 0 and j > 0:
        if chess[i][j][0] == '↖':
            s3.append(chess[i][0][0])
            i -= 1
            j -= 1
        if chess[i][j][0] == '←':
            j -= 1
        if chess[i][j][0] == '↑':
            i -= 1
    s3.reverse()
    return s3

def MEAN(arr):
    length = len(arr)
    if length > 0:
        summary = 0
        for i, v in enumerate(arr):
            summary += v
        return summary / length
    else:
         return 0

def NUMPY(tensor):
    try:
        return tensor.detach().cpu().numpy()
    except Exception as e:
        return tensor

def calc_ent(x):
    """
        calculate shanno ent of x
    """

    #x_value_list = set([x[i] for i in range(x.shape[0])])
    # [divider, models]
    ent = 0.0
    len = x.shape[1]
    sum = torch.sum(x).item()
    for i in range(len):
        p = float(torch.sum(x[:, i]).item() / sum)
        if p > 0:
            #p = float(x[x == x_value].shape[0]) / x.shape[0]
            logp = np.log2(p)
            ent -= p * logp

    return ent

def getInterval(start, end = -1):
    if end == -1:
        end = start
    return '{}h~{}h'.format(2*start, 2*end + 2)

def decision_tree(x, ent = 0, offset = 0):
    len = x.shape[0]
    if ent == 0:
        ent = calc_ent(x)
    decisions = [-1 for i in range(len)]
        
    ent_gain_max = 0.
    gain_index = 0
    last_ent_a = -1.
    last_ent_b = -1.
    for j in range(1, len):
        ent_a = calc_ent(x[:j, :])
        ent_b = calc_ent(x[j:, :])
        ent_gain = ent - j/len*ent_a - (len-j)/len*ent_b
        if ent_gain > ent_gain_max:
            gain_index = j
            ent_gain_max = ent_gain
            last_ent_a = ent_a
            last_ent_b = ent_b
    left_decisions = []
    right_decisions = []
    tree = []
    timeL = getInterval(offset, offset+gain_index-1)
    timeC = getInterval(offset, offset+len-1)
    timeR = getInterval(offset+gain_index, offset+len-1)
    if len > 1:
        curr_node = timeC
    else:
        curr_node = getInterval(offset)

    if gain_index == 0:
        type = torch.argmax(x[0]).item()
        left_decisions = [type for j in range(len)]
        tree.append([curr_node, 'ARIMA{}'.format(type)])
    else:
        if gain_index > 1:
            left_node = timeL
        else:
            left_node = getInterval(offset)
        if gain_index < len - 1:
            right_node = timeR
        else:
            right_node = getInterval(offset+gain_index)
        tree.append([curr_node, left_node])
        tree.append([curr_node, right_node])
        if last_ent_a == 0 or gain_index == 1:
            type = torch.argmax(x[0]).item()
            tree.append([left_node, 'ARIMA{}'.format(type)])
            left_decisions = [type for j in range(gain_index)]
        else:
            left_decisions, left_tree = decision_tree(x[:gain_index, :], last_ent_a, offset)
            tree += left_tree

        if last_ent_b == 0 or gain_index == len - 1:
            type = torch.argmax(x[-1]).item()
            tree.append([right_node, 'ARIMA{}'.format(type)])
            right_decisions = [type for j in range(len - gain_index)]
        else:
            right_decisions, right_tree = decision_tree(x[gain_index:, :], last_ent_b, offset + gain_index)
            tree += right_tree
    return (left_decisions + right_decisions), tree

def transformForTree(x, models):
    dividers = x.shape[1]
    f = torch.zeros([dividers, models])
    for j in range(dividers):
        for i in range(models):
            f[j][i] = torch.sum(x[:,j] == i).item()

    return f


if __name__ == "__main__":
    models = 7
    dividers = 12
    #x = torch.zeros(2000, dividers)
    x = torch.randint(models, [2000, dividers])
    f = transformForTree(x, models)
    decisions, tree = decision_tree(f)
    g = Digraph('决策树')
    for k in tree:
        g.edge(k[0], k[1])
    g.view()

    print(decisions)
    print(tree)
    pass
import torch
import json
import time
from .dcnn_model import *
from .seq2seq_model import *
from .gat_model import GAT, SpGAT
from .config import *
from .dLoader import *
import json
'''
model = SpGAT(nfeat=INPUT_WIDTH, 
                nhid=FEATURE_SIZE,
                nclass=OUTPUT_WIDTH, 
                dropout=DROP_OUT, 
                nheads=ATTENTION_LEVEL, 
                alpha=LEAKY_ALPHA,
                cuda=True)

model.load_state_dict(torch.load(ROOT_PATH + '/model.pkl'))
'''
model = LinearDiffDim(INPUT_WIDTH, OUTPUT_WIDTH, 1)
model.load_state_dict(torch.load(ROOT_PATH + '/ARIMA_beijing_I{}_D0_O{}.pkl'.format(INPUT_WIDTH, OUTPUT_WIDTH)))
model.cuda()
model.eval()


# Load data
dataSet = networkRoadDataset(ROAD_SET)
roads = []

with open(DATA_PATH + '/data-' + ROAD_SET + '/road_net.json') as f:
    road_net = json.load(f)
roads = list(road_net.keys())

len_roads = len(roads)
batch_len = dataSet.loadDataSet(roads, NEIGHBOUR_LEVEL, in_window = INPUT_WIDTH, delay_window = DELAY_WIDTH, out_window = OUTPUT_WIDTH)
loader = dataSet.getBatch(roads)
adj = dataSet.getAdj(roads)
last_mae = [0 for i in range(len_roads)]
last_mape = [0 for i in range(len_roads)]
last_rmse = [0 for i in range(len_roads)]
last_loss = 0

def getNext():
    start = time.time()
    global last_mae
    global last_mape
    global last_rmse
    global last_loss
    (x, y, y_max, y_mean, step) = next(loader)
    (x, y, y_max, y_mean) = x.float().cuda(), y.float().cuda(), y_max.float().cuda(), y_mean.float().cuda()
    output = model(x)
    #output = model(x, adj)
    diff = torch.abs(output - y)
    loss = torch.mean(diff.mul(y_max)).item()
    mae = torch.mean(diff.mul(y_max), dim = 1).data.cpu().numpy().tolist()
    mape = torch.mean(100 * diff / (y + y_mean + 1e-9), dim = 1).data.cpu().numpy().tolist()
    rmse = torch.mean((diff.mul(y_max) ** 2) ** 0.5, dim = 1).data.cpu().numpy().tolist()
    acc = (1 - torch.mean(diff)).item()
    res = {}
    data = {}
    for i in range(len_roads):
        data[roads[i]] = ((output[i] + y_mean[i]).mul(y_max[i])).data.cpu().numpy().tolist()
        res[roads[i]] = [last_mae[i], last_mape[i], last_rmse[i]]
    resp = json.dumps({
        'data': data,
        'res': res,
        'loss': last_loss,
        'cost': time.time() - start,
        'step': step,
    })
    last_mae = mae
    last_mape = mape
    last_rmse = rmse
    last_loss = loss
    return resp
<template>
  <div id="app">
    <!--<div id="mask" v-show="loading"></div>-->
    <div
      class="titleTag"
      style="top:20px"
    >
      <p>交通数据集：RTIC(7555)</p>
      <hr/>
      <p>{{nowStr}}</p>
    </div>
    <Card
      class="left table"
      style="top:20px"
    >
      <strong class="list-title">路段影响力排名表</strong>
      <p></p>
      <Table
        ref="prTable"
        :loading="initializing"
        :data="roadTable"
        :columns="roadTableColumns"
        stripe
        style="margin-top: 10px;"
        @on-row-click="(row) => activeRoad(row.CODE)"
      />
      <div style="margin: 10px;overflow: hidden">
        <div style="float: left;">
          <Button
            type="default"
            shape="circle"
            size="small"
            icon="md-cloud-download"
            @click="exportPR2CSV"
          >
            导出CSV
          </Button>
        </div>
        <div style="float: right;">
            <Page
              :total="roadCounts"
              :current="1"
              size="small"
              simple
              @on-change="changeTablePage"
            />
        </div>
      </div>
    </Card>
    <Card
      class="left info all-transition"
      style="bottom:90px"
      :style="{opacity: currentRoad ? 1 : 0}"
    >
      <strong
        v-if="currentRoadData"
        class="list-title"
        style="width: 100%; color: white; padding: 5px 0px; margin-bottom: 5px; display: inline-block"
        :style="{backgroundColor: currentRoadData.color}"
      >
        {{ `【${currentRoadData.CODE}】${currentRoadData.NAME}` }}
      </strong>
      <div id="sub-map" style="height: 200px">
      </div>
      <div v-if="currentRoadData">
        <List>
            <li class="list-item-large">
              <label>道路速度均值</label>：
              <Tag color="primary" class="val">{{`${currentRoadData.mean}km/h(历史)` + (currentRoadData.avgSpeed ? `，${currentRoadData.avgSpeed}km/h(预测)` : '')}}</Tag>
            </li>
            <li class="list-item-large">
              <label>可预测度</label>：
              <Tag color="primary" class="val">{{ `${currentRoadData.st_pi}%(空间)，${currentRoadData.act_pi}%(时间)`}}</Tag>
            </li>
            <li class="list-item-large">
              <label>PageRank值</label>：
              <Tag color="primary" class="val">{{ `${currentRoadData.pr}`}}</Tag>
            </li>
            <li
              class="list-item-large"
              v-if="currentRoadData.crowed != null"
            >
              <label>拥堵程度</label>：
              <Tag :color="congestionColors[currentRoadData.crowed]" class="val">{{ congestionLabels[currentRoadData.crowed] }}</Tag>
            </li>
            <li
              class="list-item-large"
              v-if="currentRoadData.predict"
            >
              <label>预测速度值：</label>
              <div
                class="val"
                style="display:inline-block"
              >
                <template v-for="(item, index) in currentRoadData.predict">
                  <Tooltip
                    :key="`speed${index}`"
                    :content="`未来${index*15}-${index*15+15}分钟平均速度为${item.toFixed(2)}km/h`"
                    placement="top"
                  >
                    <div
                      class="speedBox"
                      :style="{backgroundColor: speedColors(item/80)}"
                    />
                  </Tooltip>
                </template>
              </div>
            </li>
        </List>
      </div>
    </Card>
    <div class="right-group">
      <transition-group name="slide-from-right" :duration="200">
        <div
          v-show="lastData"
          class="right chart"
          ref="lossChart"
          key="loss"
          style="top:20px"
        />
        <div
          v-show="lastData"
          class="right chart"
          ref="costChart"
          key="cost"
          style="top:290px"
        />
        <div
          v-show="lastData"
          class="right list"
          style="top:560px;"
          key="list"
        >
          <strong class="list-title">拥堵路段: {{ crowedList.length ? `${crowedList.length}条` : '无' }}</strong>
          <keep-alive include="Scroll">
            <Scroll
              :height="200"
              :distance-to-edge="-50"
              :on-reach-bottom="loadMoreCrowed"
            >
              <List size="small" border>
                  <li
                    class="list-item"
                    v-for="(item, index) in scrollList"
                    :key="`crowd${index}`"
                    @click="activeRoad(item.id)"
                  >
                    <span>{{ item.text }}</span>
                    <Tag :color="item.color" class="list-tag">{{ item.tag }}</Tag>
                  </li>
              </List>
            </Scroll>
          </keep-alive>
        </div>
      </transition-group>
      <div
        class="right legend"
        style="bottom:90px"
      >
        <template v-if="selectView===0">
          <div
            class="legend-item"
            :style="{ backgroundImage: `linear-gradient(to right, ${speedColors(0)} , ${speedColors(0.5)}, ${speedColors(1)})` }"
          >
          </div>
          <div class="legend-text">
            <p>
              <span style="float:left">0km/h（平均车速）</span>
              <span style="float:right">80km/h</span>
            </p>
          </div>
        </template>
        <template v-if="selectView===1">
          <div
            class="legend-item"
          >
            <div style="width: 20%; display: inline-block; font-size: 16px;"><strong>拥堵</strong>：</div>
            <div style="width: 80%; display: inline-block">
              <div
                v-for="(item, index) in congestionColors"
                :key="`clusterLegendDiv${index}`"
                :style="{backgroundColor: item, width: `${(parseFloat(100 / congestionColors.length)).toFixed(1)}%`}"
                style="display: inline-block; height: 100%;"
              >{{ `${congestionLabels[index]}` }}</div>
            </div>
          </div>
        </template>
        <template v-if="selectView===2">
          <div
            class="legend-item"
            :style="{ backgroundImage: `linear-gradient(to right, ${rankColors(0)} , ${rankColors(1)})` }"
          >
          </div>
          <div class="legend-text">
            <p>
              <span style="float:left">高（影响力）</span>
              <span style="float:right">低</span>
            </p>
          </div>
        </template>
        <template v-if="selectView===3">
          <div
            class="legend-item"
          >
            <div style="width: 20%; display: inline-block; font-size: 16px;"><strong>类别</strong>：</div>
            <div style="width: 80%; display: inline-block">
              <div
                v-for="(item, index) in clusterData"
                :key="`clusterLegendDiv${index}`"
                :style="{backgroundColor: item.color, width: `${(parseFloat(100 / clusterData.length)).toFixed(1)}%`}"
                style="display: inline-block; height: 100%;"
              >{{ `${(index + 1)}` }}</div>
            </div>
          </div>
        </template>
      </div>
    </div>
    <div id="map"></div>
    <div id="tools">
      <template>
        <Button
          v-if="keepPredict"
          class="button"
          type="error"
          @click="togglePredict"
        >暂停预测 <Icon type="ios-pause" /></Button>
        <Button
          v-else
          class="button"
          type="primary"
          :disabled="loading"
          @click="togglePredict"
        >开始预测 <Icon type="ios-play" /></Button>
        <Poptip class="button">
          <div slot="content">
            <AutoComplete
              :value="fromRoadText"
              :data="fromSource"
              placement="top-start"
              placeholder="出发地"
              @on-select="(value) => handleSelectRoad(value, 'from')"
              @on-search="(value) => handleSearch(value, 'from')"
              style="width:150px"></AutoComplete>至
            <AutoComplete
              :value="toRoadText"
              :data="toSource"
              placement="top-start"
              placeholder="到达地"
              @on-select="(value) => handleSelectRoad(value, 'to')"
              @on-search="(value) => handleSearch(value, 'to')"
              style="width:150px"></AutoComplete>
            <Button
              type="default"
              icon="ios-search"
              style="margin-left: 10px"
              :disable="fromRoad && toRoad"
              @click="getRoute"
            ></Button>
          </div>
          <Button
            class="button"
            type="default"
            :disabled="loading || !lastData"
          >查找路线 <Icon type="ios-search" /></Button>
        </Poptip>
      </template>
      <Form class="form" inline>
        <FormItem label="视图类型">
          <Select
            v-model="selectView"
            placeholder="请选择视图类型"
            class="select"
            style="width:150px"
            @on-change="renderView"
          >
            <Option
              v-for="(item, index) in dataViews"
              :value="item.type"
              :disabled="item.disabled"
              :key="`view${index}`">
              {{ item.label }}
            </Option>
          </Select>
        </FormItem>
        <FormItem label="路段筛选">
          <Select
            v-model="selectClusters"
            class="select"
            placeholder="请选择路段类别"
            multiple
            style="width:350px;"
            :max-tag-count="3"
            @on-change="filterRoads"
          >
            <Option
              v-for="(item, index) in clusterData"
              class="select-item"
              :label="`类别${index + 1}`"
              :value="index"
              :key="`cluster${index}`">
              <div :style="{width: '16px', float: 'left', backgroundColor: item.color}"></div>{{ item.label }}
            </Option>
          </Select>
          <Select
            v-model="selectModules"
            class="select"
            placeholder="请选择适配特定模型的路段"
            multiple
            style="width:200px;"
            :max-tag-count="1"
            @on-change="filterRoads"
          >
            <Option
              v-for="(item, index) in moduleData"
              class="select-item"
              :label="item"
              :value="index"
              :key="`module${index}`">
              {{ item }}
            </Option>
          </Select>
        </FormItem>
        <FormItem label="预测区间">
            <Slider
              v-model="predictSpan"
              :min="15"
              :max="120"
              :step="15"
              :tip-format="spanStr"
              :marks="spanMarks"
              show-stops
              range
              @on-change="updateAll"
              style="width:350px;"
            />
        </FormItem>
      </Form>
    </div>
  </div>
</template>

<script>
import echarts from 'echarts';
import { colorGradient, hex2rgb } from './utils';
import { DATAVIEW_TYPE } from './static';

/* global L */
/* global topojson */
export default {
  name: 'app',
  data() {
    return {
      loading: true,
      initializing: true,
      speedColors: colorGradient([[0, '#B10026'], [0.5, '#FD8D3C'], [1, '#FFFFB2']]),
      congestionColors: ['#B10026','#FF6666','#FFCC66','#99CCCC'],
      congestionLabels: ['严重','中度','轻微','通畅'],
      rankColors: colorGradient([[0, '#F00'], [1, '#FFF']]),
      clusterColors: ['#c33', '#f00', '#f60', '#f96', '#6c9', '#6cf', '#09c', '#969'],
      clusterData: [],
      selectClusters: [],
      moduleData: ['ARIMA', 'ARIMA+S2S', 'HCNN', 'HCNN+S2S'],
      selectModules: [0, 1, 2, 3],
      selectView: 3,
      currentType: 0,
      fromRoad: null,
      fromRoadText: '',
      fromSource: [],
      toRoad: '',
      toRoadText: '',
      toSource: [],
      currentRoad: null,
      lastData: null,
      keepPredict: false,
      taskDef: 2,
      chains: {},
      nowStr: '',
      crowedList: [],
      scrollList: [],
      predictSpan: [15, 120],
      roadTable: [],
      roadTableColumns: [
        {
          title: '编号',
          key: 'CODE',
        },
        {
          title: '名称',
          key: 'NAME',
          ellipsis: true,
        },
        {
          title: 'PageRank值',
          key: 'pr',
          ellipsis: true,
          render: (h, params) => {
            const row = params.row;
            const text = row.pr ? (1 + 9 * (row.pr - this.prData.min) / (this.prData.max - this.prData.min)) : 0;
            
            return h('span', {
              style: {
                color: 'white',
                padding: '0 5px',
                backgroundColor: 'red',
              }
            }, text.toFixed(2));
          },
        },
      ],
      onePageRoads: 7,
      pageIndex: 1,
      roadCounts: 0,
      spanMarks: {
        30: '30min',
        60: '1h',
        120: '2h',
      },
      // cluster, lastData, prData, roadSource
      // roads(map), lossChart(echart), costChart(echart),
      // errors(lossChart), costs(costChart)
      // propertiesData, geoData,
      //[0.08, '#cfc'], 
    };
  },
  computed: {
    currentRoadData() {
      const { lastData, propertiesData, cluster, prData, currentRoad:id, clusterColors} = this;
      let res = null;
      if (id) {
        if(lastData) {
          res = {
            ...propertiesData[id],
            predict: lastData[id],
            cluster: cluster[id],
          };
          const avgSpeed = res.predict.reduce((x, y) => x + y) / res.predict.length;
          res.avgSpeed = avgSpeed.toFixed(2);
          if (avgSpeed > 30) {
            res.crowed = 3;
          } else {
            res.crowed = Math.floor(avgSpeed / 10);
          }
        } else {
          res = {
            ...propertiesData[id],
            cluster: cluster[id],
          };
        }
        res.color = clusterColors[res.cluster];
        res.LENGTH = (res.LENGTH * 1e3).toFixed(1)
        res.pr = res.pr ? (1 + 9 * (res.pr - prData.min) / (prData.max - prData.min)).toFixed(2) : (0).toFixed(2);
      }
      return res;
    },
    dataViews() {
      const {cluster, prData, lastData } = this;
      return [
        {
          label: '速度预测视图',
          disabled: lastData === null,
          type: DATAVIEW_TYPE.SPEED,
        },
        {
          label: '拥堵视图',
          disabled: lastData === null,
          type: DATAVIEW_TYPE.CONGESTION, 
        },
        {
          label: '影响力视图',
          disabled: prData === null,
          type: DATAVIEW_TYPE.RANK,
        },
        {
          label: '分类视图',
          disabled: cluster === null,
          type: DATAVIEW_TYPE.CLUSTER,
        },
      ];
    },
  },
  mounted() {
    this.$Loading.start();
    const mymap = L.map('map', {
      zoomControl: false,
      maxBoundsViscosity: 1.0,
    });
    const submap =  L.map('sub-map', {
      zoomControl: false,
      maxBoundsViscosity: 1.0,
    });
    const osm = new L.TileLayer('http://219.224.169.45:6058/osm_tiles/{z}/{x}/{y}.png', {
      minZoom: 3,
      maxZoom: 18,
      attribution: 'BUAA',
    });
    //mymap.setView(new L.LatLng(34.153547, -118.294082), 11);
    mymap.setView(new L.LatLng( 39.92,116.42 ), 11);
    mymap.setMaxBounds([[-90, -180], [90, 180]]);
    mymap.addLayer(osm);
    submap.setView(new L.LatLng( 39.92,116.42 ), 11);
    submap.setMaxBounds([[-90, -180], [90, 180]]);
    
    const legend = L.control({position: 'topright'});
    legend.onAdd = function () {
        var div = L.DomUtil.create('div', 'info map-legend'),
            grades = ['red', 'orange'],
            labels = ['关键路链', '影响路段'];
        // loop through our density intervals and generate a label with a colored square for each interval
        for (var i = 0; i < grades.length; i++) {
            div.innerHTML +=
                '<i style="background:' + grades[i] + '"></i> ' +
                labels[i] + (labels[i + 1] ? '<br/>' : '');
        }
        return div;
    };
    legend.addTo(submap);
    const subOsm = new L.TileLayer('http://219.224.169.45:6058/osm_tiles/{z}/{x}/{y}.png', {
      minZoom: 3,
      maxZoom: 18,
      attribution: 'BUAA',
    });
    submap.addLayer(subOsm);

    const lossChart = echarts.init(this.$refs.lossChart, {}, {
      renderer: 'canvas',
    });
    const costChart = echarts.init(this.$refs.costChart, {}, {
      renderer: 'canvas',
    });
    this.errors = [];
    this.costs = [[],[],[],[]];
    lossChart.setOption({
      title: {
        text: '平均预测误差(km/h)',
      },
      xAxis: {
        type: 'time',
      },
      yAxis: {
        type: 'value',
      },
      series: [{
        name: '模拟数据',
        type: 'line',
        showSymbol: false,
        data: this.errors,
      }]
    });
    this.lossChart = lossChart;
    this.costChart = costChart;
    this.updateCostChart();
    this.map = mymap;
    this.subMap = submap;

    this.$ajax.get('./Beijing_Road.json').then((response) => {
    //this.$ajax.get('./Pems_Road.json').then((response) => {
      const root = response.data;
      const geoData = topojson.feature(root,root.objects['Beijing_Road']).features;
      //const geoData = topojson.feature(root,root.objects['Pems_Road']).features;
      /*
      const root = response.data;
      const data = topojson.feature(root,root.objects['Beijing_Road']).features;
      this.roads = L.geoJSON(data, {
        coordsToLatLng: function (coords) {
          return L.CRS.EPSG4326.unproject(L.point(coords[0]-0.006, coords[1]-0.0015));
        }
      });*/
      //console.log(geoData) // eslint-disable-line
      this.$ajax.get('./cluster.json').then((response) => {
        const data = response.data;
        const finalGeo = geoData.filter((item) => {
          return data[item.properties.CODE] >= 0;
        });
        const geo = {};
        const propertiesData = {};
        const roadSource = [];
        for(let i = 0; i < finalGeo.length; i += 1){
          const key = finalGeo[i].properties.CODE;
          geo[key] = finalGeo[i].geometry,
          propertiesData[key] = finalGeo[i].properties;
          propertiesData[key].prSource = 0;
          if (propertiesData[key].NAME) {
            roadSource.push(propertiesData[key]);
          }
        }
        this.geoData = geo;
        const colors = this.clusterColors;
        this.roads = L.geoJSON(finalGeo, {
          coordsToLatLng: function (coords) {
            return L.CRS.EPSG4326.unproject(L.point(coords[0]-0.006, coords[1]-0.0015));
          },
          onEachFeature: (feature, layer) => {
              //bind click
              // const id = feature.properties.CODE;
              layer.bindTooltip(feature.properties.NAME);
              layer.on({
                mouseover: () => {
                  layer.setStyle({
                    weight: 30,
                    opacity: 0.5,
                  }) //eslint-disable-line
                  layer.openTooltip();
                },
                mouseout: () => {
                  layer.setStyle({
                    weight: 5,
                    opacity: 1,
                  }) //eslint-disable-line
                },
                click: () => {
                  const id = feature.properties.CODE;
                  this.activeRoad(id);
                }
                /*
                click: () => {
                  console.log('click feature') //eslint-disable-line
                  console.log(this.chains[id]) //eslint-disable-line
                  this.roads.setStyle((feature) => {
                    const h_id = feature.properties.CODE;
                    if(this.chains[id] && this.chains[id].has(h_id)) {
                      return {color: '#f00'};
                    }
                  })
                }
                */
              });
          },
          style: function (feature) {
            const id = feature.properties.CODE;
            return {color: colors[data[id]], weight: 5};
          },
          /*
          pointToLayer : function(feature, latlng) {
            const id = feature.properties.CODE;
            if(!data[id])
              return null;
              console.log(id) // eslint-disable-line
            return L.circleMarker(latlng, {
                radius : 5,
                fillColor : speedColors[data[id]],
                color : speedColors[data[id]],
                weight : 1,
                opacity : 1,
                fillOpacity : 0.8
            });
          }
          */
        });
        this.roads.addTo(this.map);
        this.cluster = data;
        this.$ajax.get('./page_rank.json').then((response) => {
          const data = response.data;
          var min = 1;
          var max = -10e9;
          for(let k in data){
            const pr = Math.log(data[k]);
            /*
            if(propertiesData[k].NAME.indexOf('西直门')<0) {
              continue;
            }*/
            propertiesData[k].prSource = data[k];
            propertiesData[k].pr = pr;
            if(pr < min) {
              min = pr
            } else if(pr > max) {
              max = pr
            }
          }
          this.prData = {
            min,
            max,
          };
          this.roadSource = roadSource.sort((a, b) => {
            return b.prSource - a.prSource;
          });
          this.roadCounts = roadSource.length;
          this.initializing = false;
          this.changeTablePage();
          this.$ajax.get('./pais.json').then((response) => {
            const data = response.data;
            for(let k in data) {
              propertiesData[k] = {
                ...propertiesData[k],
                act_pi: (data[k][1] * 100).toFixed(2),
                st_pi: (data[k][4] * 100 + 5).toFixed(2),
                mean: (data[k][5] * 80).toFixed(2),
                std: (data[k][6] * 80).toFixed(2),
              }
            }
            this.$ajax.get('./road_chain.txt').then((response) => {
              const data = response.data.split('\n');
              for(let i in data) {
                data[i] = data[i].replace(/\s/g, '')
                let item = data[i].split(',');
                if(propertiesData[item[0]]) {
                  let nb = propertiesData[item[0]].nb;
                  if(!nb) {
                    propertiesData[item[0]].nb = new Set(item);
                    propertiesData[item[0]].nextNB = item;
                  }
                  else {
                    const { nextNB = [] } = propertiesData[item[0]];
                    if (!nextNB || item.length > nextNB.length) {
                      propertiesData[item[0]].nextNB = item;
                    }
                    propertiesData[item[0]].nb = new Set([...item, ...Array.from(nb)])
                  }
                }
                const len = item.length - 1;
                if(propertiesData[item[len]]) {
                  let nb = propertiesData[item[len]].nb;
                  if(!nb) {
                    propertiesData[item[len]].nb = new Set(item);
                    propertiesData[item[len]].prevNB = item;
                  }
                  else {
                    const { prevNB = [] } = propertiesData[item[len]];
                    if (!prevNB || item.length > prevNB.length) {
                      propertiesData[item[len]].prevNB = item;
                    }
                    propertiesData[item[len]].nb = new Set([...item, ...Array.from(nb)])
                  }
                }
              }
              this.propertiesData = propertiesData;
              this.$ajax.get('./cluster_center.json').then((response) => {
                const data = response.data;
                const legends = [];
                const selectType = [];
                for(let i = 0; i < data.length; i += 1) {
                  legends.push({
                    label: `类别${i + 1} (路段数${data[i][0]}, 可预测度${(data[i][2] * 100).toFixed(2)}%)`,
                    center: data[i],
                    color: colors[i],
                  });
                  selectType.push(i);
                }
                this.selectClusters = selectType;
                this.clusterData = legends;
                // console.log(legends); //eslint-disable-line
                this.loading = false;
                // console.log(this.propertiesData); //eslint-disable-line
                this.$Loading.finish();
              });
            });
          });
        });
      });
    });
    this.$ajax('./road_net.json').then((response) => {
      this.roadNet = response.data;
    })
  },
  methods: {
    updateCostChart() {
      this.costChart.setOption({
        xAxis: {
          type: 'time',
        },
        yAxis: {
          type: 'value',
        },
        legend:{
          //默认横向布局，纵向布局值为'vertical'
          orient:'horizontal'
        },
        series: [
          {
            name: '总耗时(s)',
            type: 'line',
            showSymbol: false,
            data: this.costs[0],
          },
          {
            name: 'ARIMA耗时(s)',
            type: 'line',
            showSymbol: false,
            data: this.costs[1],
          },
          {
            name: 'Seq2Seq耗时(s)',
            type: 'line',
            showSymbol: false,
            data: this.costs[2],
          },
          {
            name: 'HCNN耗时(s)',
            type: 'line',
            showSymbol: false,
            data: this.costs[3],
          },
        ]
      });
    },
    changeTablePage(index) {
      const { roadSource, pageIndex, onePageRoads } = this;
      const idx = index || pageIndex;
      const start = (idx - 1) * onePageRoads;
      if (index) {
        this.pageIndex = idx;
      }
      this.roadTable = roadSource.slice(start, start + onePageRoads);
    },
    filterRoads() {
      const { selectClusters, cluster, selectModules, roads, propertiesData } = this;
      if (!roads) {
        return;
      }
      roads.setStyle((feature) => {
        const id = feature.properties.CODE;
        const type = cluster[id];
        const { act_pi, st_pi } = propertiesData[id];
        let module = parseFloat(act_pi) > parseFloat(st_pi) ? 0 : 2;
        module += parseInt(act_pi) > 60 ? 0 : 1;
        if((type >= 0) && (selectClusters.indexOf(type) >= 0) && (selectModules.indexOf(module) >= 0)) {
          return {
            weight: 5,
          };
        } else {
          return {
            weight: 0,
          };
        }
      })
    },
    getCrowedList() {
      const { propertiesData, predictSpan, congestionColors, congestionLabels, lastData:data } = this;
      const start = Math.floor(predictSpan[0] / 15) - 1;
      const end = Math.floor(predictSpan[1] / 15);
      let crowedList = [];
      for(let k in data) {
        const tp = data[k].slice(start, end).reduce((x, y) => x + y) / data[k].length;
        if(tp < 30) {
          const lev = Math.floor(tp/10);
          const name = propertiesData[k].NAME;
          if(name) {
            crowedList.push({
              id: k,
              text: `【${k}】${name}`,
              level: lev,
              tag: `${congestionLabels[lev]}(${tp.toFixed(2)}km/h)`,
              speed: tp,
              color: congestionColors[lev],
            });
          }
        }
      }
      // console.log(crowedList); //eslint-disable-line
      crowedList = crowedList.sort((a, b) => a.speed - b.speed);
      this.crowedList = crowedList;
      this.scrollList = crowedList.slice(0, 100);
    },
    loadMoreCrowed() {
      const start = this.scrollList.length;
      return new Promise((resolve) => {
        if (start < this.crowedList.length) {
          setTimeout(() => {
            this.scrollList = this.scrollList.concat(this.crowedList.slice(start, start + 100));
            resolve();
          }, 1000);
        } else {
          resolve();
        }
      });
    },
    renderView() {
      const { selectView, lastData, prData, speedColors, congestionColors, rankColors, cluster, clusterColors, predictSpan, propertiesData } = this;
      let renderFunc = null;
      let data = null;
      const start = Math.floor(predictSpan[0] / 15) - 1;
      const end = Math.floor(predictSpan[1] / 15);
      const len = end - start;
      switch(selectView){
        case(DATAVIEW_TYPE.SPEED):
          data = lastData;
          renderFunc = (feature) => {
            const id = feature.properties.CODE;
            const val = data[id].slice(start, end).reduce((x, y) => x + y) / len;
            return {color: speedColors(val/80)};
          }
          break;
        case(DATAVIEW_TYPE.CONGESTION):
          data = lastData;
          renderFunc = (feature) => {
            const id = feature.properties.CODE;
            const val = data[id].slice(start, end).reduce((x, y) => x + y) / len;
            if (val > 30) {
              return {color: congestionColors[3]};
            } else {
              return {color: congestionColors[Math.floor(val/10)]};
            }
          }
          break;
        case(DATAVIEW_TYPE.RANK):
          data = propertiesData;
          var min = prData.min;
          var max = prData.max;
          renderFunc = (feature) => {
            const id = feature.properties.CODE;
            const val = data[id].pr;
            if (val) {
              let value = Math.pow(1 - (val - min)/(max - min), 0.7);
              if(feature.properties.NAME.indexOf('西%直%门'.replace(/%/g, '')) >= 0) {
                value /= 2.5;
              }
              const color = hex2rgb(rankColors(value));
              return {color: `rgba(${color.join(',')}, ${1-0.3*value})`};
              //return {color: rankColors(value)};
            } else {
              return {color: 'rgba(255, 255, 255, 0)'};
            }
          }
          break;
        default:
          data = cluster;
          renderFunc = (feature) => {
            const id = feature.properties.CODE;
            return {color: clusterColors[data[id]]};
          }
      }
      this.roads.setStyle(renderFunc);
    },
    updateAll() {
      this.renderView();
      this.getCrowedList();
    },
    togglePredict() {
      this.keepPredict = !this.keepPredict;
    },
    loadNext() {
      const { lossChart, errors, costs  } = this;
      this.loading = true;
      this.$Loading.start();
      this.$ajax.get('/api').then((response) => {
        const { data, loss, cost, step } = response.data;
        const now = new Date( + new Date(new Date(2016, 3, 1).toString()) + step * 8 * 15 * 60000);
        const nowStr = now.toLocaleDateString() + ' ' + now.getHours() + now.toLocaleTimeString().substr(-6,6);
        if(errors.length > 100) {
          errors.shift();
        }
        if(costs[0].length > 100) {
          for(let i = 0; i < costs.length; i += 1) {
            costs[i].shift();
          }
        }
        errors.push({
          value: [
            nowStr,
            loss,
          ],
        });
        for(let i = 0; i < costs.length; i += 1) {
          costs[i].push({
            value: [
              nowStr,
              cost[i],
            ],
          });
        }
        lossChart.setOption({
          series:[{
            data: this.errors,
          }],
        });
        this.updateCostChart();
        if(this.selectView > DATAVIEW_TYPE.CONGESTION) {
          this.selectView = DATAVIEW_TYPE.SPEED;
          this.$Notice.info({
            title: '视图变更通知',
            desc: '进入预测模式，已自动切换至预测速度视图',
          });
        }
        this.nowStr = nowStr;
        this.lastData = data;
        this.updateAll();
        this.loading = false;
        this.$Loading.finish();
        if (this.keepPredict) {
          this.loadNext();
        }
        //this.loadNext();
      });
    },
    spanStr(val) {
      const s = val;
      const start_h = s >= 60 ? `${Math.floor(s/60)}h` : '';
      const start_min = s % 60 ? `${s%60}min` : '';
      return `未来${start_h}${start_min}`;
    },
    exportPR2CSV() {
      const { roadSource, prData } = this;
      const { min, max } = prData;
      const output = [];
      for(let i = 0; i < roadSource.length; i += 1) {
        let row = roadSource[i];
        output.push({
          ...row,
          pr: row.pr ? (1 + 9 * (row.pr - min) / (max - min)).toFixed(2) : (0).toFixed(2),
        })
      }
      this.$refs.prTable.exportCsv({
        filename: 'Beijing Road PR marks',
        columns: this.roadTableColumns,
        data: output,
      });
    },
    activeRoad(id) {
      const { propertiesData, geoData, subMap, map } = this;
      if(this.propertiesData[id]) {
        this.currentRoad = id;
        // console.log(propertiesData[id]); //eslint-disable-line
        const nb = Array.from(propertiesData[id].nb || new Set());
        const { prevNB = [], nextNB = [], } = propertiesData[id];
        const geo = geoData[id].coordinates;
        // console.log(geo); //eslint-disable-line
        const collectSet = new Set([id]);
        let geojson = [{
          geometry: geoData[id],
          properties: propertiesData[id],
          type: 'Feature',
          color: 'red',
          weight: 6,
        }];
        for(let i = 0; i < prevNB.length; i += 1){
          let item = prevNB[i];
          if(collectSet.has(item)) {
            continue;
          }
          collectSet.add(item);
          geojson.push({
            geometry: geoData[item],
            properties: propertiesData[item],
            type: 'Feature',
            color: '#f66',
            weight: 6,
          });
        }
        for(let i = 0; i < nextNB.length; i += 1){
          let item = nextNB[i];
          if(collectSet.has(item)) {
            continue;
          }
          collectSet.add(item);
          geojson.push({
            geometry: geoData[item],
            properties: propertiesData[item],
            type: 'Feature',
            color: '#f66',
            weight: 6,
          });
        }
        for(let i = 0; i < nb.length; i += 1) {
          let item = nb[i];
          if(collectSet.has(item)) {
            continue;
          }
          collectSet.add(item);
          geojson.push({
            geometry: geoData[item],
            properties: propertiesData[item],
            type: 'Feature',
            color: 'orange',
            weight: 3,
          });
        }
        geojson = geojson.sort((a, b) => a.weight - b.weight);
        if (this.subRoads) {
          subMap.removeLayer(this.subRoads);
          subMap.removeLayer(this.subMarks);
          map.removeLayer(this.marks);
        }
        this.subRoads = L.geoJSON(geojson, {
          coordsToLatLng: function (coords) {
            return L.CRS.EPSG4326.unproject(L.point(coords[0]-0.006, coords[1]-0.0015));
          },
          onEachFeature: (feature, Layer) => {
            const NAME = feature.properties.NAME || `路段${feature.properties.CODE}`;
            Layer.bindTooltip(NAME);
          },
          style: (feature) => {
            return {color: feature.color, weight: feature.weight};
          },
        }).addTo(subMap);
        const bounds = this.subRoads.getBounds();
        subMap.fitBounds(bounds);
        const geoLen = geo.length - 1;
        const subMarks = L.layerGroup([
          L.circleMarker([geo[0][1]-0.0015, geo[0][0]-0.006], {
            color: 'white',
            fillColor: 'red',
            radius: 5,
          }),
          L.circleMarker([geo[geoLen][1]-0.0015, geo[geoLen][0]-0.006], {
            color: 'white',
            fillColor: 'red',
            radius: 5,
          }),
        ]);
        subMarks.addTo(subMap);
        const marks = L.layerGroup([
          L.marker([geo[0][1]-0.0015, geo[0][0]-0.006]),
          L.marker([geo[geoLen][1]-0.0015, geo[geoLen][0]-0.006]),
        ]);
        marks.addTo(map);
        this.marks = marks;
        this.subMarks = subMarks;
        /*
        this.subRoads.eachLayer((Layer) => {
          if (Layer.feature.weight > 3) {
            Layer.openTooltip();
          }
        })*/
      }
    },
    handleSearch(value, type) {
      const { roadSource } = this;
      const tp_source = [];
      for(let i = 0; i < roadSource.length; i += 1){
        const item = roadSource[i];
        if(item.NAME.indexOf(value) >= 0) {
          tp_source.push(`【${item.CODE}】${item.NAME}`);
        }
      }
      this[`${type}Source`] = tp_source;
    },
    handleSelectRoad(value, type) {
      const str = value.split('】');
      str[0] = str[0].replace('【','');
      const code = str[0];
      const name = str[1];
      this[`${type}Road`] = code;
      if(name) {
        this[`${type}RoadText`] = name;
      } else {
        this[`${type}RoadText`] = `路段${code}`;
      }
    },
    getRoute() {
      const { propertiesData, fromRoad, toRoad, roadNet, lastData, map, geoData } = this;
      const timeMax = lastData[fromRoad].length;
      const { X: fromX, Y: fromY } = propertiesData[fromRoad];
      const { X: toX, Y: toY } = propertiesData[toRoad];
      const from_geo = [fromY, fromX];
      const to_geo = [toY, toX];
      const total_dis = map.distance(from_geo, to_geo)
      let stack = [{
        id: fromRoad,
        time: 0,
        dis: total_dis,
      }];
      let outputChain = [];
      let resChain = [];
      const roadChain = [];
      const lifeTree = {};
      const failRoads = new Set();
      while(stack.length > 0 && stack.length < 7555) {
        const item = stack.shift();
        //console.log(`use ${item.id}`); //eslint-disable-line
        const { id:tp, time:tp_time } = item;
        const timing = Math.min(Math.floor(tp_time / 15), timeMax);
        const nextNB = roadNet[tp].d;
        let findFlag = false;
        let nextOnes = [];
        for(let i = 0; i < nextNB.length; i += 1){
          const test_tp = nextNB[i];
          if (stack.indexOf(test_tp) >= 0 || roadChain.indexOf(test_tp) >= 0 || test_tp === tp || failRoads.has(test_tp)) {
            /*
            console.log(test_tp); //eslint-disable-line
            console.log(stack.indexOf(test_tp)); //eslint-disable-line
            console.log(roadChain.indexOf(test_tp)); //eslint-disable-line
            console.log(test_tp === tp); //eslint-disable-line
            console.log(failRoads.has(test_tp)); //eslint-disable-line
            */
            continue;
          }
          const { X: testX, Y: testY, LENGTH: testLen } = propertiesData[test_tp];
          const test_geo = [testY, testX];
          const test_dis = map.distance(test_geo, to_geo);
          const test_val = (testLen / (lastData[test_tp][timing] + 1e-9)) * 60;
          if (isNaN(test_val) || (test_dis - total_dis) > 5000) {
            continue;
          }
          const test_item = {
            id: test_tp,
            time: tp_time + test_val,
            dis: test_dis,
            prev: tp,
          }
          if(test_tp === toRoad) {
            outputChain.push(item);
            outputChain.push(test_item);
            const str = `${roadChain.join(',')},${item.id},${test_item.id}`;
            const cost = tp_time + test_val
            resChain.push({
              str,
              cost,
            });
            console.log(`find result: ${str}, cost: ${cost}`); // eslint-disable-line
            outputChain.pop();
            outputChain.pop();
            nextOnes = [];
            findFlag = true;
            break;
          }
          nextOnes.push(test_item);
        }
        nextOnes = nextOnes.sort((a, b) => (a.dis - b.dis));
        if (nextOnes.length > 0) {
          lifeTree[item.id] = nextOnes.length;
          outputChain.push(item);
          roadChain.push(item.id);
          stack = nextOnes.concat(stack);
          //console.log(`go ${item.id}`); //eslint-disable-line
        } else {
          lifeTree[item.prev] -= 1;
          let last = outputChain[outputChain.length - 1];
          while(last && (lifeTree[last.id] <= 0)) {
            if (!findFlag) {
              console.log(last.id); //eslint-disable-line
              failRoads.add(last.id);
            }
            //console.log(`back ${last.id}`); //eslint-disable-line
            outputChain.pop();
            roadChain.pop();
            if (last.prev) {
              lifeTree[last.prev] -= 1;
            }
            last = outputChain[outputChain.length - 1];
          }
        }
        if (outputChain.length > 2 && (outputChain[outputChain.length - 1].time < outputChain[outputChain.length - 2].time)) {
          console.log(stack); //eslint-disable-line
          console.log(lifeTree); //eslint-disable-line
          console.log(outputChain); //eslint-disable-line
          return;
        }
        //nextOnes = nextOnes.sort((a, b) => (a.time - b.time));
      }
      resChain = resChain.sort((a, b) => {
        return a.cost - b.cost;
      });
      if (resChain.length) {
        outputChain = resChain[0].str.split(',');
        const chainGeo = [];
        for(let i = 0; i < outputChain.length; i += 1){
          chainGeo.push({
            geometry: geoData[outputChain[i]],
            type: 'Feature',
          });
        }
        if (this.roadRoute) {
          map.removeLayer(this.roadRoute);
        }
        this.roadRoute = L.geoJSON(chainGeo, {
          coordsToLatLng: function (coords) {
            return L.CRS.EPSG4326.unproject(L.point(coords[0]-0.006, coords[1]-0.0015));
          },
          style: () => {
            return { weight: 10 };
          },
        }).addTo(map);
        this.$Notice.info({
          title: '查找成功',
          desc: `最优路线预期总旅行时长：${parseInt(resChain[0].cost)}分钟`,
        });
      }
      else {
        this.$Notice.error({
          title: '查找失败',
          desc: '未找到合适路线',
        });
      }
      return;
    },
  },
  watch: {
    keepPredict(newVal, oldVal) {
      if(newVal && !oldVal) {
        if(!this.loading) {
          this.loadNext();
        }
      }
    },
  }
}
</script>

<style lang="less">
#app {
  @media(min-width: 1920px) {
    min-width: 1903px;
    min-height: 908px;
  }
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  position: absolute;
  bottom: 0px;
  top: 0px;
  overflow-x: hidden;
  width: 100%;
  #map {
    position: absolute;
    height: 100%;
    width: 100%;
    overflow: hidden;
    /*
    .leaflet-pane.leaflet-tile-pane{
      opacity: 0.5;
    }*/
  }
  #tools {
    position: absolute;
    bottom: 0;
    width: 100%;
    z-index: 1000;
    text-align: center;
    background-color: rgba(0, 0, 0, 0.5);
    padding: 20px;
    .button {
      float: right;
      margin-right: 10px;
    }
    .form {
      float: left;
      .ivu-form-item-label,.ivu-slider-marks-item {
        color: white;
      }
      .ivu-form-item {
        margin-bottom: 0;
      }
      .ivu-form-item-content {
        float: left;
      }
      .select {
        float: left;
        margin-right: 10px;
        .select-item {
          text-align: left;
          font-size: 16px;
          >div {
            width: 16px;
            height: 16px;
            display: inline-block;
            margin-right: 8px;
          }
        }
      }
    }
  }
  #mask {
    position: absolute;
    overflow: hidden;
    z-index: 1001;
    height: 100%;
    width: 100%;
    background: rgba(255, 255, 255, 0.25);
    cursor: progress;
  }
  .left {
    padding: 5px;
    position: absolute;
    z-index: 1000;
    width: 420px;
    height: auto;
    left: 20px;
    background: rgba(255, 255, 255, 0.5);
  }
  .info {
    height: auto;
  }
  .right {
    position: absolute;
    z-index: 1000;
    height: 250px;
    width: 400px;
    right: 20px;
    background: rgba(255, 255, 255, 0.5);
    padding: 5px;
  }
  .legend {
    height: auto;
    padding: 10px;
    background: rgba(0, 0, 0, 0.75);
    color: white;
    &-item {
      width: 100%;
      height: 20px;
      line-height: 20px;
      text-align: center;
    }
    &-text {
      margin-top: 5px;
      font-weight: bold;
      font-size: 14px;
      line-height: 16px;
      width: 100%;
    }
  }
  .list {
    height: 250px;
    padding: 5px;
    &-title {
      color: #333;
      font-size: 18px;
    }
    &-item {
      display: inline-block;
      width: 100%;
      cursor: pointer;
      &:hover {
        font-weight: bold;
        background: rgba(255, 255, 255, 0.8);
      }
    }
    &-item-large {
      >label {
        font-weight: bold;
      }
      >.val {
        float: right;
      }
      display: inline-block;
      width: 100%;
      font-size: 16px;
      padding: 5px;
      border-bottom: 1px solid lightgray;
    }
    &-tag {
      float: right;
    }
  }
  .titleTag {
    position: absolute;
    color: white;
    z-index: 1000;
    text-align: center;
    font-size: 20px;
    padding: 10px;
    font-weight: bold;
    height: auto;
    width: 400px;
    left: calc(50% - 200px);
    background: rgba(0, 0, 0, 0.75);
  }
  .speedBox {
    width: 20px;
    height: 20px;
    margin-right: 5px;
    border: 1px solid white;
    float: left;
    transition: all ease 300ms;
    cursor: pointer;
    &:hover {
      opacity: 0.7;
      border: 3px solid white;
    }
  }
	.map-legend {
		line-height: 24px;
		color: white;
		background: rgba(0, 0, 0, 0.75);
		padding: 5px;
	}
	.map-legend i {
		padding: 2px;
		width: 18px;
		height: 18px;
		float: left;
		margin-right: 8px;
		opacity: 0.7;
	}
  // overwrite
  .ivu-card-body {
    padding: 0;
  }
  .ivu-table td, .ivu-table th{
    height: 36px !important;
    cursor: pointer;
  }
  .ivu-auto-complete .ivu-select-dropdown-list {
    max-height: 300px;
    overflow-y: scroll;
  }
  // transition
  .all-transition {
    transition: all 0.5s linear;
  }
  .slide-from-left-enter-active, .slide-from-left-leave-active {
    transition: all 0.5s linear;
    transform: translate3d(0, 0, 0);
  }
  .slide-from-left-enter, .slide-from-left-leave {
    transform: translate3d(-100%, 0, 0);
  }
  .slide-from-right-enter-active, .slide-from-right-leave-active {
    transition: all 0.5s linear;
    transform: translate3d(0, 0, 0);
  }
  .slide-from-right-enter, .slide-from-right-leave {
    transform: translate3d(100%, 0, 0);
  }
}
</style>

export const DATAVIEW_TYPE = Object.freeze({
    SPEED: 0,
    CONGESTION: 1,
    RANK: 2,
    CLUSTER: 3,
});
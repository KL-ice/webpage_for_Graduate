
function _colorInterpolation (src, dst) {
    return (x) => {
        const colors = [];
        for(let i = 0; i < 3; i += 1) {
        colors[i] = src[i] + x * (dst[i] - src[i]);
        }
        return _rgb2hex(colors);
    }
}
function _rgb2hex(colors) {
    for(let i = 0; i < colors.length; i += 1){
        const tpColor = parseInt(colors[i]).toString(16);
        colors[i] = tpColor.length > 1 ? tpColor : `0${tpColor}`;
    }
    return '#' + colors.join('');
}
function _hex2rgb(colorstr) {
    colorstr = colorstr.replace('#', '');
    if (colorstr.length === 3) {
        let newStr = '';
        for(let i = 0; i < 3; i++) {
            newStr += colorstr[i] + colorstr[i];
        }
        colorstr = newStr;
    }
    return [parseInt(colorstr.substr(0, 2), 16), parseInt(colorstr.substr(2, 2), 16), parseInt(colorstr.substr(4, 2), 16)];
}
export function colorTur(color, rate) {
    let randomColor = [];
    color = _hex2rgb(color);
    for(let i = 0; i < 3; i += 1){
        randomColor.push((rate * color[i]) + (1 - rate) * parseInt(Math.random() * 255));
    }
    return this._rgb2hex(randomColor);
}


export function colorSet(N) {
    const colors= []
    for(let i = 0; i < N; i += 1) {
        let randC = [96 + parseInt(Math.random()*128), 96 + parseInt(Math.random()*128), 96 + parseInt(Math.random()*128)]
        colors.push(_rgb2hex(randC))
    }
    return colors;
}

/**
 * 颜色渐变插值函数生成器
 * @param {*} breakpoints , 渐变描述数组，每个item为[progress, color]的pair形式，progress取值0～1, color为16进制颜色字符串（3字符或6字符）
 * return 插值函数，根据传入的值(0～1)生成对应颜色16进制字符串
*/

export function colorGradient(breakpoints) {
    if (breakpoints[0][0] != 0) {
        breakpoints.splice(0, 0, [0, '#ffffff']);
    }
    const len = breakpoints.length;
    const colors = [];
    for(let i = 0; i < len; i += 1) {
        colors.push(_hex2rgb(breakpoints[i][1]));
    }
    const colorFunc = [];
    for(let i = 0; i < len - 1; i += 1) {
        colorFunc.push(_colorInterpolation(colors[i], colors[i + 1]));
    }
    return (x) => {
        x = Math.max(x, 0);
        x = Math.min(x, 1);
        let i = -1;
        let end = breakpoints[i + 1][0];
        let start = 0;
        while(x >= end && i < len - 2) {
            i += 1;
            start = end;
            end = breakpoints[i + 1][0]
        }
        return colorFunc[i]((x - start) / (end - start));
    }
}

export function hex2rgb(colorStr) {
    return _hex2rgb(colorStr);
}